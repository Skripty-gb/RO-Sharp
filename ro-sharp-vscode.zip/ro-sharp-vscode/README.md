# RO-Sharp for VS Code

Syntax highlighting si rulare pentru **RO-Sharp** (.rop).

## Features
- Syntax highlighting cu culori pentru fiecare tip de comanda
- Tema **RO-Sharp Dark** cu culorile tricolorului roman
- Buton **▶** in toolbar pentru rulare directa
- **F5** pentru rulare rapida
- Click dreapta → **RO-Sharp: Ruleaza fisierul**
- Rulare selectie de cod
- Output panel dedicat cu timp de executie

## Instalare
```bash
cp -r ro-sharp ~/.vscode/extensions/ro-sharp
```
Reporneste VS Code.

## Configurare
In `settings.json` poti schimba calea interpretor:
```json
{
  "rosharp.interpreterPath": "rop"
}
```
