const vscode = require('vscode');
const path = require('path');
const os = require('os');

function getRopCommand(filePath) {
    const homeDir = os.homedir();
    const interpretor = path.join(homeDir, '.ROSharp', 'interpretor.py');
    return `python3 "${interpretor}" "${filePath}"`;
}

function activate(context) {
    let disposable = vscode.commands.registerCommand('rosharp.runFile', function () {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('Nu exista un fisier deschis!');
            return;
        }

        const filePath = editor.document.fileName;
        if (!filePath.endsWith('.rop')) {
            vscode.window.showErrorMessage('Fisierul nu este un program RO-Sharp (.rop)!');
            return;
        }

        editor.document.save().then(() => {
            const cmd = getRopCommand(filePath);
            let terminal = vscode.window.terminals.find(t => t.name === 'RO-Sharp');
            if (!terminal) {
                terminal = vscode.window.createTerminal({
                    name: 'RO-Sharp',
                    shellPath: '/bin/bash'
                });
            }
            terminal.show(true);
            terminal.sendText(cmd);
        });
    });

    context.subscriptions.push(disposable);
}

function deactivate() {}

module.exports = { activate, deactivate };
